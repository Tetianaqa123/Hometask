 package OOP.Task2;

public class Rectangle1 extends Rectangle{
    private double length;
    private double width;

    public void Rectangle1 (double width, double length)
    {
        this.width = width;
        this.length = length;
    }

}
