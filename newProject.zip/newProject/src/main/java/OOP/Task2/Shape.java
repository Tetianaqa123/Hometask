package OOP.Task2;

interface Shape {
    public  double getSquare();

}

