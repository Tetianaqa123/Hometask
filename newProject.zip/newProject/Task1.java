public class Task1 {
    public static void main(String[] args) {
        System.out.println(24 + 26);
    }
}
